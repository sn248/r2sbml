2013-10-16 <mhucka@caltech.edu>

These files are a subset of the Google Code Prettify syntax highlighting
system for web pages, version of 4 March 2013, obtained from the
following URL: http://code.google.com/p/google-code-prettify/

The complete Google Code Prettify provides a number of additional style
files for various languages.  We only need the language support provided
by defaults, and we define additional styling in our own CSS files
(specifically in doxygen-base-stylesheet.css).  To save space, we only
remain a subset of the full Prettify system.

Google Code Prettify is distributed under the terms of the Apache
License 2.0.
